#!/bin/sh
/usr/sbin/sar -u 1 5 | /usr/bin/grep Average | /usr/bin/awk '{print "PHYSICAL_PROCESSORS " $6 " " "\nCAPACITY_CONSUMED " $7}'
