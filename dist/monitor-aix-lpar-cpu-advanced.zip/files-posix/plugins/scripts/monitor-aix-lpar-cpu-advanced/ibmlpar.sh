#!/bin/sh
/usr/local/uptime/apache/bin/php ibmlpar.php
