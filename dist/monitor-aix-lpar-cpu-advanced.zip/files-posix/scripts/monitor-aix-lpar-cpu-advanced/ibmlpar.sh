#!/bin/sh
/usr/local/uptime/apache/bin/php ../../plugins/scripts/monitor-aix-lpar-cpu-advanced/ibmlpar.php
